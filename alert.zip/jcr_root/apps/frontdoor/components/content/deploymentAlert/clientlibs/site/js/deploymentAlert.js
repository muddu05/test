// create and append empty model section on body
var appendModalStructures = function () {
  var structure = '<section class="modal modal-activate"><div id="model-content" class="modal-content"></div></section>';
  document.querySelector('body').insertAdjacentHTML('beforeend', structure);
};

//append authored text to alert box
var appendModelcontent = function () {
  var text = document.getElementById("deploymentalert").value;
  document.querySelector('.modal-content').innerHTML = text;
};

// add event listener to close alert box on click anywhere outside alert box
document.addEventListener('click', function (event) {
  var isClickInside = document.getElementById('model-content').contains(event.target);
  if (!isClickInside) {
    document.querySelector('.modal').classList.remove("modal-activate");
  }
});

appendModalStructures();
appendModelcontent();